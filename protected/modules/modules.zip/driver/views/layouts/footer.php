
<div id="jplayer"></div>

<?php 
$this->renderPartial('/index/new-task',array(   
));

$this->renderPartial('/index/assign-task',array(   
));

$this->renderPartial('/index/task-details',array(   
));

$this->renderPartial('/index/task-change-status',array(   
));

$this->renderPartial('/index/driver-details',array(   
));

$this->renderPartial('/index/notification-tpl',array(   
));

$this->renderPartial('/index/map-location',array(   
));

$this->renderPartial('/index/send-push-form-driver',array(   
));

$this->renderPartial('/index/send-push-form-bulk',array(   
));
?>

<div class="main-preloader">
   <div class="inner">
   <div class="ploader"></div>
   </div>
</div> 

</html>